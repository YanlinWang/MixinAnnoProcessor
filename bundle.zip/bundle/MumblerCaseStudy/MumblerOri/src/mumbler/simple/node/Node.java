package mumbler.simple.node;

import mumbler.simple.Evaluatable;

public abstract class Node implements Evaluatable  {
}

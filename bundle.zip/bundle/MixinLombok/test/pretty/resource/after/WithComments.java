/*
Try out pretty comments.
 */
package test;

// Cool Comments
public class WithComments {
	// Also inside the body
// On start of line
}
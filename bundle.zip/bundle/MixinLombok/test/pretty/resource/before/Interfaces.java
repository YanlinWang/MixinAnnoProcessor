@SuppressWarnings("all")
interface Interfaces {
	enum Ranks {
		CLUBS,
		HEARTS,
		DIAMONDS,
		SPADES;
	}
	;
	;
	int x = 10;
	void y();
	public static final int a = 20;
	public abstract void b();
}

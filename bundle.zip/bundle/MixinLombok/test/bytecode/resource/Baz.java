public interface Baz {
}
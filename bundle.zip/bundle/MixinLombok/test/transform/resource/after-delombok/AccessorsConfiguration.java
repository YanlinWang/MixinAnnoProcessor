class AccessorsConfiguration {
	private String m_FieldName = "";
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public String fieldName() {
		return this.m_FieldName;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public void fieldName(final String m_FieldName) {
		this.m_FieldName = m_FieldName;
	}
}
class AccessorsConfiguration2 {
	private String m_FieldName = "";
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public void setM_FieldName(final String m_FieldName) {
		this.m_FieldName = m_FieldName;
	}
}
class AccessorsConfiguration3 {
	private String fFieldName = "";
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public AccessorsConfiguration3 setFieldName(final String fFieldName) {
		this.fFieldName = fFieldName;
		return this;
	}
}
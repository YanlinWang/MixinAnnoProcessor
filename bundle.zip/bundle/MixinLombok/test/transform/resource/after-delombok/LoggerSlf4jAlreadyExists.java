class LoggerSlf4jAlreadyExists {
	int log;
}
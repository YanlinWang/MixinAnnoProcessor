/**
 * Doc on package
 */
package testPackage;
/** Weird doc */
/**
 * Doc on class
 */
class JavadocGenerally {
	/**
	 * Doc on field
	 */
	private int someField;
	/**
	 * Doc on method
	 */
	public void test() {
	}
	/**
	 * Doc on inner
	 */
	public interface TestingInner {
	}
}

class GetterAccessLevel {
	boolean isNone;
	boolean isPrivate;
	boolean isPackage;
	boolean isProtected;
	boolean isPublic;
	String noneString;
	String privateString;
	String packageString;
	String protectedString;
	String publicString;
	String value;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	private boolean isPrivate() {
		return this.isPrivate;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	boolean isPackage() {
		return this.isPackage;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	protected boolean isProtected() {
		return this.isProtected;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public boolean isPublic() {
		return this.isPublic;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	private String getPrivateString() {
		return this.privateString;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	String getPackageString() {
		return this.packageString;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	protected String getProtectedString() {
		return this.protectedString;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public String getPublicString() {
		return this.publicString;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public String getValue() {
		return this.value;
	}
}
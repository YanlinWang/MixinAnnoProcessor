class GetterOnClass1 {
	boolean isNone;
	boolean isPublic;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public boolean isPublic() {
		return this.isPublic;
	}
}
class GetterOnClass2 {
	boolean isNone;
	boolean isProtected;
	boolean isPackage;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	protected boolean isProtected() {
		return this.isProtected;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	boolean isPackage() {
		return this.isPackage;
	}
}
class GetterOnClass3 {
	boolean isNone;
	boolean isPackage;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	boolean isPackage() {
		return this.isPackage;
	}
}
class GetterOnClass4 {
	boolean isNone;
	boolean isPrivate;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	private boolean isPrivate() {
		return this.isPrivate;
	}
}
class GetterOnClass5 {
	boolean isNone;
	boolean isPublic;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public boolean isPublic() {
		return this.isPublic;
	}
}
class GetterOnClass6 {
	String couldBeNull;
	@lombok.NonNull
	String nonNull;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public String getCouldBeNull() {
		return this.couldBeNull;
	}
	@lombok.NonNull
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public String getNonNull() {
		return this.nonNull;
	}
}
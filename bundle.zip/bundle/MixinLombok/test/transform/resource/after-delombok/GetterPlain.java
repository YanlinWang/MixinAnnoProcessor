class GetterPlain {
	int i;
	int foo;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int getI() {
		return this.i;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int getFoo() {
		return this.foo;
	}
}
class ConflictingStaticConstructorNames {
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public boolean equals(final java.lang.Object o) {
		if (o == this) return true;
		if (!(o instanceof ConflictingStaticConstructorNames)) return false;
		final ConflictingStaticConstructorNames other = (ConflictingStaticConstructorNames) o;
		if (!other.canEqual((java.lang.Object) this)) return false;
		return true;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	protected boolean canEqual(final java.lang.Object other) {
		return other instanceof ConflictingStaticConstructorNames;
	}
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int hashCode() {
		int result = 1;
		return result;
	}
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public java.lang.String toString() {
		return "ConflictingStaticConstructorNames()";
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public ConflictingStaticConstructorNames() {
	}
}
class Getter {
	static boolean foo;
	static int bar;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public static boolean isFoo() {
		return Getter.foo;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public static int getBar() {
		return Getter.bar;
	}
}

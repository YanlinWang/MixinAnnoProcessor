class GenerateSuppressFBWarnings {
	int y;
	@java.lang.SuppressWarnings("all")
	@edu.umd.cs.findbugs.annotations.SuppressFBWarnings(justification = "generated code")
	@javax.annotation.Generated("lombok")
	public int getY() {
		return this.y;
	}
}
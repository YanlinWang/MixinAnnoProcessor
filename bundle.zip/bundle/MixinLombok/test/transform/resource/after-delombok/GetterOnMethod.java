class GetterOnMethod {
	int i;
	int j;
	int k;
	public @interface Test {
	}
	@Deprecated
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int getI() {
		return this.i;
	}
	@java.lang.Deprecated
	@Test
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int getJ() {
		return this.j;
	}
	@java.lang.Deprecated
	@Test
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int getK() {
		return this.k;
	}
}

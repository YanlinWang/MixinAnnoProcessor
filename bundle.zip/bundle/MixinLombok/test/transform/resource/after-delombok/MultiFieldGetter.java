class MultiFieldGetter {
	int x;
	int y;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	protected int getX() {
		return this.x;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	protected int getY() {
		return this.y;
	}
}
class MultiFieldGetter2 {
	int x;
	int y;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	int getX() {
		return this.x;
	}
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	int getY() {
		return this.y;
	}
}
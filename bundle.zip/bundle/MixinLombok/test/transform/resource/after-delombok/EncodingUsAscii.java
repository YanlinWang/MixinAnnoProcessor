//ENCODING: US-ASCII
class EncodingUsAscii {
	String foo\u0e51\u0e51 = "\016\t\b ";
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public java.lang.String toString() {
		return "EncodingUsAscii(foo\u0e51\u0e51=" + this.foo\u0e51\u0e51 + ")";
	}
}
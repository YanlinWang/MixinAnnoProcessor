class LoggerWithConfig {
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	private final org.slf4j.Logger myLogger = org.slf4j.LoggerFactory.getLogger(LoggerWithConfig.class);
}
class LoggerJul {
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	private static final java.util.logging.Logger log = java.util.logging.Logger.getLogger(LoggerJul.class.getName());
}
class LoggerJulWithImport {
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	private static final java.util.logging.Logger log = java.util.logging.Logger.getLogger(LoggerJulWithImport.class.getName());
}
class LoggerJulWithDifferentName {
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	private static final java.util.logging.Logger log = java.util.logging.Logger.getLogger("DifferentName");
}
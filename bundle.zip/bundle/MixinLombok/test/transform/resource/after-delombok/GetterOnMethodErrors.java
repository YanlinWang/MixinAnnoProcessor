class PlaceFillerToMakeSurePositionIsRelevant {
}
class GetterOnMethodErrors {
	private int test;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int getTest() {
		return this.test;
	}
}